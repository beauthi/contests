#/usr/bin/python3

from parser import *

libraries_num = input().split()

score = 0

for _ in range(libraries_num):
    library[1]

first_line = input().split()
B, L, D = int(first_line[0]), int(first_line[1]), int(first_line[2])
books = list(map(int, input().split()))